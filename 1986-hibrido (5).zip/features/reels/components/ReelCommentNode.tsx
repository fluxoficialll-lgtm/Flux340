
// This file is deprecated. Please use @/components/ui/comments/CommentItem.tsx
export {};
