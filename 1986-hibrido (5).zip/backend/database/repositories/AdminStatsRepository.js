
// Este arquivo foi substituído pela estrutura modular em ./admin/index.js
// Favor utilizar AdminStatsHub para novas métricas globais.
